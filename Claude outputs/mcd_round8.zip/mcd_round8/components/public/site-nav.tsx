"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";

// Find a Doctor is intentionally left out of nav for now — Angel wants it
// off until there are more providers/the brand is better known. The page
// itself (app/find-a-doctor/page.tsx) is fully live and reachable by
// direct link/QR/demo — only the nav entry is withheld. Add `{ href:
// "/find-a-doctor", label: "Find a Doctor" }` to LINKS below when ready.
const LINKS = [
  { href: "/", label: "Home" },
  { href: "/features", label: "Features" },
  { href: "/pricing", label: "Pricing" },
  { href: "/security", label: "Security" },
  { href: "/about", label: "About Us" },
];

// Shared chrome for every PUBLIC page (Part 3). The secure clinic
// workspace (/dashboard/*) uses components/emr/emr-shell.tsx instead —
// these two never mix, by design (Part 72).
export function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header style={{ position: "sticky", top: 0, zIndex: 30, background: "rgba(15,90,140,0.96)", backdropFilter: "blur(6px)", borderBottom: "1px solid rgba(4,156,160,0.2)" }}>
      <div style={{ maxWidth: 1120, margin: "0 auto", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none", flexShrink: 0 }}>
          <Image src="/logo-64.png" alt="MyCareDesk logo" width={30} height={30} style={{ borderRadius: 7 }} priority />
          <span style={{ fontWeight: 800, fontSize: 18, color: "#f4f5f7", letterSpacing: 0.3 }}>
            My<span style={{ color: "var(--brand-accent)" }}>Care</span>Desk
          </span>
        </Link>

        <nav style={{ display: "none", gap: 22 }} className="site-nav-links">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              style={{
                fontSize: 13.5,
                color: pathname === l.href ? "var(--brand-accent)" : "rgba(244,245,247,0.8)",
                fontWeight: pathname === l.href ? 700 : 500,
                textDecoration: "none",
              }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div style={{ display: "none", alignItems: "center", gap: 10 }} className="site-nav-cta">
          <Link href="/patient-signup" style={{ fontSize: 13, color: "rgba(244,245,247,0.85)", textDecoration: "none" }}>For Patients</Link>
          <Link href="/login" style={{ fontSize: 13, color: "rgba(244,245,247,0.85)", textDecoration: "none" }}>Sign In</Link>
          <Link href="/request-demo" style={{ fontSize: 13, color: "var(--brand-accent)", border: "1px solid rgba(4,156,160,0.5)", borderRadius: 8, padding: "8px 14px", textDecoration: "none", fontWeight: 600 }}>
            Request a Demo
          </Link>
          <Link href="/signup" style={{ fontSize: 13, background: "var(--brand-secondary)", color: "var(--brand-primary-dark)", borderRadius: 8, padding: "8px 16px", textDecoration: "none", fontWeight: 700 }}>
            Start Your Trial
          </Link>
        </div>

        <button
          onClick={() => setOpen((o) => !o)}
          className="site-nav-toggle"
          style={{ background: "none", border: "1px solid rgba(4,156,160,0.4)", borderRadius: 8, color: "var(--brand-accent)", padding: "6px 10px", fontSize: 13 }}
        >
          {open ? "✕" : "☰"}
        </button>
      </div>

      {open && (
        <div className="site-nav-mobile" style={{ padding: "8px 24px 18px", display: "grid", gap: 10 }}>
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)} style={{ fontSize: 14, color: "#f4f5f7", textDecoration: "none" }}>
              {l.label}
            </Link>
          ))}
          <Link href="/patient-signup" onClick={() => setOpen(false)} style={{ fontSize: 14, color: "#f4f5f7", textDecoration: "none" }}>For Patients</Link>
          <Link href="/login" onClick={() => setOpen(false)} style={{ fontSize: 14, color: "#f4f5f7", textDecoration: "none" }}>Sign In</Link>
          <Link href="/request-demo" onClick={() => setOpen(false)} style={{ fontSize: 14, color: "var(--brand-accent)", textDecoration: "none", fontWeight: 700 }}>Request a Demo</Link>
          <Link href="/signup" onClick={() => setOpen(false)} style={{ fontSize: 14, color: "var(--brand-accent)", textDecoration: "none", fontWeight: 700 }}>Start Your Trial →</Link>
        </div>
      )}

      <style>{`
        @media (min-width: 860px) {
          .site-nav-links { display: flex !important; }
          .site-nav-cta { display: flex !important; }
          .site-nav-toggle { display: none !important; }
        }
      `}</style>
    </header>
  );
}
